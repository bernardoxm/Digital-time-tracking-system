import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ponto/Service/auth_Login_Service.dart';
import 'package:ponto/controller/image_select.dart';
import 'package:ponto/model/usuario.dart';
import 'package:ponto/repositorio/UsuarioRep.dart';
import 'package:ponto/utils/navigator.dart';

class PerfilPage extends StatefulWidget {
  const PerfilPage({Key? key}) : super(key: key);

  @override
  PerfilPageState createState() => PerfilPageState();
}

class PerfilPageState extends State<PerfilPage> {
  File? image;
  late ImageSelectController _imageSelectController;
  ImageProvider? _imageProvider;
  bool _isLoading = true;
  static bool isValidVoltar = false;

  @override
  void initState() {
    super.initState();
    _imageSelectController = ImageSelectController();
    _initImage();
    _fetchUserData();
  }

  Future<void> _initImage() async {
    await _imageSelectController.initSharedPreferences();
    File? savedImage = await _imageSelectController.getSavedImage();
    if (savedImage != null) {
      setState(() {
        image = savedImage;
        _imageProvider = FileImage(savedImage);
        _isLoading = false;
      });
    } else {
      setState(() {
        _imageProvider =
            const AssetImage("lib/assets/image/defaultprofile.png");
        _isLoading = false;
      });
    }
  }

  Future<void> _fetchUserData() async {
    String? token = AuthService.accessToken;
    String? userId = AuthService.userId;

    if (token != null && userId != null) {
      await UsuarioRep.fetchAndAddUser(token, userId);
    } else {
      print('Token ou ID de usuário não encontrado');
    }

    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final double widthbox = MediaQuery.of(context).size.width * 0.9;
    final double fontSizeall = MediaQuery.of(context).size.width * 0.04;

    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            SafeArea(
              child: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color.fromARGB(255, 0, 191, 99),
                      Color.fromARGB(255, 0, 191, 99),
                    ],
                  ),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(100),
                    bottomRight: Radius.circular(0),
                  ),
                ),
                child: Column(
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.1,
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.5,
                      height: MediaQuery.of(context).size.height * 0.3,
                      child: GestureDetector(
                        onTap: () async {
                          File? pickedImage =
                              await _imageSelectController.pickImage(context);

                          if (pickedImage != null) {
                            setState(() {
                              image = pickedImage;
                              _imageProvider = FileImage(pickedImage);
                            });
                          }
                        },
                        child: _isLoading
                            ? const CircularProgressIndicator()
                            : CircleAvatar(
                                key: UniqueKey(),
                                radius: 75,
                                backgroundColor: Colors.transparent,
                                backgroundImage: _imageProvider,
                                foregroundColor:
                                    const Color.fromARGB(0, 255, 255, 255),
                              ),
                      ),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.5,
                      child: ListView.separated(
                        itemBuilder: (BuildContext context, int index) {
                          final Usuario usuario = UsuarioRep.tabela[index];
                          return ListTile(
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                _buildInfoText('Nome', usuario!.fullName),
                               _buildInfoText('Email', usuario!.email),
                               
                              ],
                            ),
                          );
                        },
                        padding: const EdgeInsets.all(20),
                        separatorBuilder: (_, __) => const Divider(),
                        itemCount: UsuarioRep.tabela.length,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.03,
            ),
            if (PerfilPageState.isValidVoltar)
              Container(
                width: widthbox,
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 0, 191, 99),
                  border: Border.all(
                    color: Color.fromARGB(255, 0, 191, 99),
                    width: 0.1,
                  ),
                  borderRadius: const BorderRadius.all(
                    Radius.circular(20),
                  ),
                ),
                child: TextButton(
                  onPressed: () {
                    setState(() {
                      PerfilPageState.isValidVoltar = false;
                    });
                    Get.to(NavigatorBarMenu()); // Voltar à tela anterior
                  },
                  child: Text(
                    'Voltar',
                    style: TextStyle(
                      color: Color.fromARGB(255, 255, 255, 255),
                      fontSize: fontSizeall,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoText(String label, String value) {
    double fontSizeall = MediaQuery.of(context).size.width * 0.045;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 6),
        Text('$label: $value',
            style: TextStyle(fontSize: fontSizeall, color: Colors.white)),
        const Divider(),
      ],
    );
  }
}
