import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:ponto/controller/image_select.dart';
import 'package:ponto/controller/local_auth.dart';
import 'package:ponto/model/usuario.dart';
import 'package:ponto/repositorio/UsuarioRep.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PontoNotifier extends ChangeNotifier {
  late Timer _timer;
  DateTime _now = DateTime.now();
  bool _isLoadingImage = false;
  DateFormat? _formatterDay;
  File? _image;
  late ImageSelectController _imageSelectController;
  final LocalAuthController _authController = LocalAuthController();
  late Usuario _usuario;
  late BuildContext _context;
  DateTime? _expiryDate;

  List<DateTime?> pontos = List.filled(4, null);

  PontoNotifier(this._context) {
    _imageSelectController = ImageSelectController();
    pontoExpiry();
    _initImage();
    _loadPointsLocally();
    _initUsuario();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _now = DateTime.now();
      notifyListeners();
    });
  }

  ImageProvider? imageProvider;
  bool isLoading = true;

  void _initImage() async {
    await _imageSelectController.initSharedPreferences();
    File? savedImage = await _imageSelectController.getSavedImage();
    if (savedImage != null) {
      _image = savedImage;
      imageProvider = FileImage(savedImage);
      isLoading = false;
      notifyListeners();
    } else {
      imageProvider = const AssetImage("lib/assets/image/defaultprofile.png");
      isLoading = false;
    }
  }

  void _initUsuario() {
    if (UsuarioRep.tabela.isNotEmpty) {
      _usuario = UsuarioRep.tabela[0];
    } else {
      // Handle the case when the tabela is empty
      _usuario = Usuario(
        
        fullName: 'ERRO GET USER',
        email: 'ERRO GET USER',
        // Add other necessary fields with default values
      );
    }
  }

  File? get image => _image;
  DateTime get now => _now;
  Usuario get usuario => _usuario;
  bool get isLoadingImage => _isLoadingImage;

  Future<void> pickImage(BuildContext context) async {
    _isLoadingImage = true;
    notifyListeners();

    File? pickedImage = await _imageSelectController.pickImage(context);

    if (pickedImage != null) {
      _image = pickedImage;
    }

    _isLoadingImage = false;
    notifyListeners();
  }

  void registrarPonto(int index, BuildContext context) {
    if (pontos.where((element) => element != null).length >= 4) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Você já marcou os 4 pontos hoje.'),
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    if (pontos[index] != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Este ponto já foi marcado.'),
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    pontos[index] = DateTime.now();
    notifyListeners();

    _savePointsLocally();
  }

bool pontoExpiry() {
  final validadePonto = _expiryDate?.isAfter(DateTime.now()) ?? false;
  return validadePonto;
}
  void limparPontos() {
    pontos = List.filled(4, null);
    _savePointsLocally();
  }

  Future<void> _savePointsLocally() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> pontosJson =
        pontos.map((point) => point != null ? point.toIso8601String() : '').toList();
    await prefs.setStringList('pontos', pontosJson);
  }

  Future<void> _loadPointsLocally() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? pontosJson = prefs.getStringList('pontos');
    pontos = pontosJson?.map((point) => point.isNotEmpty ? DateTime.parse(point) : null).toList() ?? List.filled(4, null);
    notifyListeners();
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }
}
