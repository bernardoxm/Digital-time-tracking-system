class DataTime {
  int? sec;
  int? min;
  int? hour;

  DataTime(this.hour, this.min, this.sec);
}