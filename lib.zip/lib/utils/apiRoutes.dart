// ignore: constant_identifier_names, non_constant_identifier_names
String APIROUTS = 'https://api-my-company.vercel.app/api/v1';
