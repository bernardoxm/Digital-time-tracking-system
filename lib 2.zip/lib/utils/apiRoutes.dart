//ROTAS DE API
// ignore: constant_identifier_names, non_constant_identifier_names
String APIROUTES = 'https://api-my-company.vercel.app/api/v1';
