//ROTAS DA APLICACAO.

class AppRoutes {
    // ignore: constant_identifier_names
  static const LOGIN = '/login.dart';
  // ignore: constant_identifier_names
  static const HOME = '/ponto.dart';
    // ignore: constant_identifier_names
static const PROFILE = '/pefil.dart';
  // ignore: constant_identifier_names
static const NAVIGATORBARMENU ='/navigator.dar';
  // ignore: constant_identifier_names
static const COMPROVANTES = '/comprovantes.dart';
static const VIDEOSCREEN = '/videoScreen.dart';
}
